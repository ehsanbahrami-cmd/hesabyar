@file:OptIn(ExperimentalLayoutApi::class)

package com.hesabyar.app

import android.content.SharedPreferences
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CardDefaults
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import java.util.Locale

val palette = listOf(
    Color(0xFFE53935), Color(0xFF8E24AA), Color(0xFF3949AB), Color(0xFF039BE5),
    Color(0xFF00897B), Color(0xFF7CB342), Color(0xFFFDD835), Color(0xFFFB8C00),
    Color(0xFF6D4C41), Color(0xFF546E7A), Color(0xFFD81B60), Color(0xFF00ACC1)
)
val RED = Color(0xFFC62828)
val GREEN = Color(0xFF2E7D32)

// ---------------------------------------------------------------- helpers
fun pd(s: String): String {
    val sb = StringBuilder()
    for (ch in s) sb.append(if (ch in '0'..'9') '۰' + (ch - '0') else ch)
    return sb.toString()
}

fun money(v: Long, toman: Boolean): String {
    val x = if (toman) v / 10 else v
    return pd(String.format(Locale.US, "%,d", x)) + if (toman) " تومان" else " ریال"
}

fun short(v: Long, toman: Boolean): String {
    val x = (if (toman) v / 10 else v).toDouble()
    return when {
        x >= 1e9 -> pd(String.format(Locale.US, "%.1f", x / 1e9)) + " میلیارد"
        x >= 1e6 -> pd(String.format(Locale.US, "%.1f", x / 1e6)) + " م"
        x >= 1e3 -> pd(String.format(Locale.US, "%.0f", x / 1e3)) + " هز"
        else -> pd(String.format(Locale.US, "%.0f", x))
    }
}

fun jdate(ts: Long): String {
    val (y, m, d) = Jalali.fromMillis(ts)
    val c = Calendar.getInstance()
    c.timeInMillis = ts
    return pd(
        String.format(
            Locale.US, "%04d/%02d/%02d  %02d:%02d", y, m, d,
            c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)
        )
    )
}

fun rangeFor(kind: Int): Pair<Long, Long> {
    val (jy, jm, _) = Jalali.now()
    return when (kind) {
        0 -> Pair(Jalali.monthStart(jy, jm), Jalali.monthStart(jy, jm + 1))
        1 -> {
            val (y, m) = Jalali.addMonths(jy, jm, -1)
            Pair(Jalali.monthStart(y, m), Jalali.monthStart(jy, jm))
        }
        2 -> {
            val (y, m) = Jalali.addMonths(jy, jm, -2)
            Pair(Jalali.monthStart(y, m), Jalali.monthStart(jy, jm + 1))
        }
        else -> Pair(Jalali.monthStart(jy, 1), Jalali.monthStart(jy + 1, 1))
    }
}

// ---------------------------------------------------------------- root
@Composable
fun App(db: Db, prefs: SharedPreferences, ext: Int, onRescan: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var local by remember { mutableStateOf(0) }
    var toman by remember { mutableStateOf(prefs.getBoolean("toman", true)) }
    var acct by remember { mutableStateOf<String?>(null) }
    val ver = ext + local
    val accts = remember(ver) { db.accounts() }
    val bump = { local += 1 }
    val titles = listOf("صندوق", "تراکنش‌ها", "گزارش", "مقایسه", "تنظیمات")
    val icons = listOf("📥", "🧾", "📊", "📈", "⚙️")

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = lightColorScheme(
            primary = Color(0xFF00796B), onPrimary = Color.White,
            primaryContainer = Color(0xFFB2DFDB), onPrimaryContainer = Color(0xFF004D40),
            secondaryContainer = Color(0xFFB2DFDB), onSecondaryContainer = Color(0xFF004D40),
            background = Color(0xFFF2F6F5), surface = Color.White
        )) {
            Scaffold(topBar = {
                Column {
                    Header()
                    if (accts.size > 1) AccountBar(accts, acct) { acct = it }
                }
            }, bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    titles.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(icons[i], fontSize = 18.sp) },
                            label = { Text(t, fontSize = 11.sp) }
                        )
                    }
                }
            }) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        0 -> TxList(db, ver, toman, true, bump, acct)
                        1 -> TxList(db, ver, toman, false, bump, acct)
                        2 -> ReportScreen(db, ver, toman, acct)
                        3 -> CompareScreen(db, ver, toman, acct)
                        else -> SettingsScreen(db, toman, onRescan, bump) {
                            toman = it
                            prefs.edit().putBoolean("toman", it).apply()
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- transactions
@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier, shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) { content() }
}

@Composable
fun Header() {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Color(0xFF004D40), Color(0xFF00897B))))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.ic_logo), null, Modifier.size(42.dp).clip(RoundedCornerShape(11.dp)))
        Spacer(Modifier.width(10.dp))
        Column {
            Text("حساب‌یار", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("مدیریت هوشمند هزینه‌ها", color = Color(0xFFB2DFDB), fontSize = 11.sp)
        }
    }
}

@Composable
fun MonthSummary(db: Db, ver: Int, toman: Boolean, acct: String?) {
    val (from, to) = rangeFor(0)
    val list = remember(ver, acct) { db.query(from, to, null, false, acct) }
    val w = list.filter { it.type == Cats.W }.sumOf { it.amount }
    val d = list.filter { it.type == Cats.D }.sumOf { it.amount }
    Box(
        Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF00695C), Color(0xFF26A69A))))
            .padding(16.dp)
    ) {
        Column {
            Text("خلاصه این ماه", color = Color(0xFFE0F2F1), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row {
                Column(Modifier.weight(1f)) {
                    Text("هزینه", color = Color(0xFFFFCDD2), fontSize = 12.sp)
                    Text(money(w, toman), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Column(Modifier.weight(1f)) {
                    Text("درآمد", color = Color(0xFFC8E6C9), fontSize = 12.sp)
                    Text(money(d, toman), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
fun TxCard(t: Tx, toman: Boolean, acctName: String?, onClick: () -> Unit) {
    val c = if (t.type == Cats.W) RED else GREEN
    val orange = Color(0xFFEF6C00)
    AppCard(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(c.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Text(if (t.type == Cats.W) "↑" else "↓", color = c, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    t.category ?: "دسته‌بندی نشده", fontWeight = FontWeight.SemiBold,
                    color = if (t.category == null) orange else Color.Unspecified
                )
                Text(jdate(t.ts) + (if (acctName != null) "  ·  " + acctName else ""), fontSize = 11.sp, color = Color.Gray)
                if (t.category == null) Text("برای انتخاب دسته لمس کنید", fontSize = 11.sp, color = orange)
            }
            Text(money(t.amount, toman), fontWeight = FontWeight.Bold, color = c, fontSize = 14.sp)
        }
    }
}

@Composable
fun TxList(db: Db, ver: Int, toman: Boolean, onlyNew: Boolean, bump: () -> Unit, acct: String?) {
    val names = remember(ver) { db.accounts().toMap() }
    var filter by remember { mutableStateOf<String?>(null) }
    var sel by remember { mutableStateOf<Tx?>(null) }
    val list = remember(ver, onlyNew, filter, acct) { db.query(0, Long.MAX_VALUE, filter, onlyNew, acct).take(500) }

    Column(Modifier.fillMaxSize()) {
        if (onlyNew) MonthSummary(db, ver, toman, acct)
        if (!onlyNew) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(filter == null, { filter = null }, { Text("همه") })
                FilterChip(filter == Cats.W, { filter = Cats.W }, { Text("برداشت") })
                FilterChip(filter == Cats.D, { filter = Cats.D }, { Text("واریز") })
            }
        } else {
            Text(
                "تراکنش‌های بدون دسته: ${pd(list.size.toString())}",
                Modifier.padding(12.dp), fontWeight = FontWeight.Bold
            )
        }
        if (list.isEmpty()) {
            Text(
                if (onlyNew) "همه تراکنش‌ها دسته‌بندی شده‌اند 👌" else "تراکنشی نیست. از تنظیمات «اسکن پیامک» را بزنید.",
                Modifier.padding(16.dp), color = Color.Gray
            )
        }
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.id }) { t -> TxCard(t, toman, if (names.size > 1) names[t.acct] else null) { sel = t } }
        }
    }
    sel?.let { t ->
        CategoryDialog(t, db, toman, onDone = { sel = null; bump() })
    }
}

@Composable
fun CategoryDialog(t: Tx, db: Db, toman: Boolean, onDone: () -> Unit) {
    var type by remember { mutableStateOf(t.type) }
    var amountText by remember { mutableStateOf(t.amount.toString()) }
    val cats = remember(type) { db.allCats(type) }

    fun save(cat: String?) {
        val amt = SmsParser.norm(amountText).replace(",", "").toLongOrNull() ?: t.amount
        db.update(t.id, cat, type, amt)
        onDone()
    }

    AlertDialog(
        onDismissRequest = onDone,
        confirmButton = { TextButton(onClick = onDone) { Text("بستن") } },
        dismissButton = { TextButton(onClick = { save(Cats.IGNORED) }) { Text("پیام مالی نیست (نادیده)") } },
        title = { Text("انتخاب دسته") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                LazyColumn(Modifier.height(380.dp)) {
                    item {
                        Text(t.body, fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(bottom = 8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(type == Cats.W, { type = Cats.W }, { Text("برداشت") })
                            FilterChip(type == Cats.D, { type = Cats.D }, { Text("واریز") })
                        }
                        OutlinedTextField(
                            amountText, { amountText = it },
                            label = { Text("مبلغ (ریال)") }, singleLine = true,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            cats.forEach { c ->
                                FilterChip(t.category == c && type == t.type, { save(c) }, { Text(c, fontSize = 13.sp) })
                            }
                        }
                    }
                }
            }
        }
    )
}

// ---------------------------------------------------------------- charts
@Composable
fun Pie(values: List<Pair<Color, Float>>, modifier: Modifier) {
    Canvas(modifier) {
        val total = values.sumOf { it.second.toDouble() }.toFloat()
        if (total <= 0f) return@Canvas
        val d = minOf(size.width, size.height)
        val tl = Offset((size.width - d) / 2f, (size.height - d) / 2f)
        var start = -90f
        values.forEach {
            val sw = 360f * it.second / total
            drawArc(it.first, start, sw, true, tl, Size(d, d))
            start += sw
        }
        drawCircle(Color.White, d * 0.28f, Offset(size.width / 2f, size.height / 2f))
    }
}

@Composable
fun HBar(frac: Float, color: Color) {
    Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0xFFE0E0E0))) {
        Box(Modifier.fillMaxWidth(frac.coerceIn(0.01f, 1f)).fillMaxHeight().background(color))
    }
}

@Composable
fun TypeToggle(type: String, onChange: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(type == Cats.W, { onChange(Cats.W) }, { Text("هزینه‌ها (برداشت)") })
        FilterChip(type == Cats.D, { onChange(Cats.D) }, { Text("درآمدها (واریز)") })
    }
}

// ---------------------------------------------------------------- report
@Composable
fun RangeDialog(onOk: (Long, Long) -> Unit, onCancel: () -> Unit) {
    val (jy, jm, jd) = Jalali.now()
    var a by remember { mutableStateOf(String.format(Locale.US, "%04d/%02d/01", jy, jm)) }
    var b by remember { mutableStateOf(String.format(Locale.US, "%04d/%02d/%02d", jy, jm, jd)) }
    var err by remember { mutableStateOf(false) }

    fun parse(s: String): Triple<Int, Int, Int>? {
        val p = SmsParser.norm(s).trim().split('/')
        if (p.size != 3) return null
        val y = p[0].toIntOrNull() ?: return null
        val m = p[1].toIntOrNull() ?: return null
        val d = p[2].toIntOrNull() ?: return null
        if (m !in 1..12 || d !in 1..31) return null
        return Triple(y, m, d)
    }

    AlertDialog(
        onDismissRequest = onCancel,
        confirmButton = {
            TextButton(onClick = {
                val x = parse(a)
                val y = parse(b)
                if (x == null || y == null) {
                    err = true
                } else {
                    val from = Jalali.dayStart(x.first, x.second, x.third)
                    val to = Jalali.dayStart(y.first, y.second, y.third) + 86400000L
                    if (to <= from) err = true else onOk(from, to)
                }
            }) { Text("تایید") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("انصراف") } },
        title = { Text("بازه دلخواه (شمسی)") },
        text = {
            Column {
                OutlinedTextField(a, { a = it }, label = { Text("از تاریخ  (مثال 1405/08/01)") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(b, { b = it }, label = { Text("تا تاریخ") }, singleLine = true)
                if (err) Text("تاریخ‌ها را درست وارد کنید", color = RED)
            }
        }
    )
}

@Composable
fun ReportScreen(db: Db, ver: Int, toman: Boolean, acct: String?) {
    var kind by remember { mutableStateOf(0) }
    var custom by remember { mutableStateOf<Pair<Long, Long>?>(null) }
    var type by remember { mutableStateOf(Cats.W) }
    var showDlg by remember { mutableStateOf(false) }

    val range = if (kind == 4 && custom != null) custom!! else rangeFor(if (kind == 4) 0 else kind)
    val from = range.first
    val to = range.second
    val list = remember(ver, from, to, acct) { db.query(from, to, null, false, acct) }
    val sumW = list.filter { it.type == Cats.W }.sumOf { it.amount }
    val sumD = list.filter { it.type == Cats.D }.sumOf { it.amount }
    val items = list.filter { it.type == type }
        .groupBy { it.category ?: "بدون دسته" }
        .map { Pair(it.key, it.value.sumOf { x -> x.amount }) }
        .sortedByDescending { it.second }
    val total = items.sumOf { it.second }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
          Column {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("این ماه", "ماه قبل", "۳ ماه اخیر", "امسال", "بازه دلخواه").forEachIndexed { i, s ->
                    FilterChip(kind == i, { if (i == 4) showDlg = true else kind = i }, { Text(s, fontSize = 13.sp) })
                }
            }
            Text(
                "از ${jdate(from).substringBefore("  ")} تا ${jdate(to - 1).substringBefore("  ")}",
                fontSize = 12.sp, color = Color.Gray
            )
          }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Row { Text("کل برداشت:"); Spacer(Modifier.weight(1f)); Text(money(sumW, toman), color = RED, fontWeight = FontWeight.Bold) }
                    Row { Text("کل واریز:"); Spacer(Modifier.weight(1f)); Text(money(sumD, toman), color = GREEN, fontWeight = FontWeight.Bold) }
                    Row {
                        Text("تراز:"); Spacer(Modifier.weight(1f))
                        Text(
                            (if (sumD - sumW < 0) "−" else "") + money(kotlin.math.abs(sumD - sumW), toman),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        item { TypeToggle(type) { type = it } }
        if (items.isEmpty()) {
            item { Text("در این بازه تراکنشی نیست.", color = Color.Gray) }
        } else {
            item {
                Pie(
                    items.mapIndexed { i, p -> Pair(palette[i % palette.size], p.second.toFloat()) },
                    Modifier.fillMaxWidth().height(200.dp)
                )
            }
            itemsIndexedCompat(items) { i, p ->
                val color = palette[i % palette.size]
                val pct = if (total > 0) p.second.toFloat() / total else 0f
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(color))
                        Spacer(Modifier.width(6.dp))
                        Text(p.first, Modifier.weight(1f), fontSize = 14.sp)
                        Text(money(p.second, toman), fontSize = 13.sp)
                        Text("  " + pd(String.format(Locale.US, "%.0f", pct * 100)) + "٪", fontSize = 12.sp, color = Color.Gray)
                    }
                    HBar(pct, color)
                }
            }
        }
    }
    if (showDlg) {
        RangeDialog(
            onOk = { f, t -> custom = Pair(f, t); kind = 4; showDlg = false },
            onCancel = { showDlg = false }
        )
    }
}

fun <T> androidx.compose.foundation.lazy.LazyListScope.itemsIndexedCompat(
    list: List<T>, content: @Composable (Int, T) -> Unit
) {
    items(list.size) { i -> content(i, list[i]) }
}

// ---------------------------------------------------------------- monthly comparison
@Composable
fun CompareScreen(db: Db, ver: Int, toman: Boolean, acct: String?) {
    var type by remember { mutableStateOf(Cats.W) }
    var cat by remember { mutableStateOf<String?>(null) }
    var months by remember { mutableStateOf(6) }
    var menu by remember { mutableStateOf(false) }

    val (jy, jm, _) = Jalali.now()
    val keys = (months - 1 downTo 0).map { Jalali.addMonths(jy, jm, -it) } // oldest -> newest
    val from = Jalali.monthStart(keys.first().first, keys.first().second)
    val to = Jalali.monthStart(jy, jm + 1)
    val all = remember(ver, type, from, to, acct) { db.query(from, to, type, false, acct) }

    fun monthOf(t: Tx): Pair<Int, Int> {
        val j = Jalali.fromMillis(t.ts)
        return Pair(j.first, j.second)
    }

    val filtered = all.filter { cat == null || (it.category ?: "بدون دسته") == cat }
    val perMonth = keys.map { k -> filtered.filter { monthOf(it) == k }.sumOf { it.amount } }
    val maxV = (perMonth.maxOrNull() ?: 0L).coerceAtLeast(1L)
    val catList = all.map { it.category ?: "بدون دسته" }.distinct()
    val color = if (type == Cats.W) RED else GREEN

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
          Column {
            TypeToggle(type) { type = it; cat = null }
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box {
                    OutlinedButton(onClick = { menu = true }) { Text(cat ?: "همه دسته‌ها") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("همه دسته‌ها") }, onClick = { cat = null; menu = false })
                        catList.forEach { c ->
                            DropdownMenuItem(text = { Text(c) }, onClick = { cat = c; menu = false })
                        }
                    }
                }
                FilterChip(months == 6, { months = 6 }, { Text("۶ ماه") })
                FilterChip(months == 12, { months = 12 }, { Text("۱۲ ماه") })
            }
          }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp).height(190.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    keys.forEachIndexed { i, k ->
                        val v = perMonth[i]
                        Column(
                            Modifier.weight(1f),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom
                        ) {
                            Text(if (v > 0) short(v, toman) else "", fontSize = 8.sp, maxLines = 1, softWrap = false)
                            Box(
                                Modifier.fillMaxWidth(0.6f)
                                    .height((110f * v / maxV).dp.coerceAtLeast(1.dp))
                                    .background(color)
                            )
                            Text(Jalali.monthNames[k.second - 1], fontSize = 9.sp, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
        item { Text("مقایسه ماه به ماه — ${cat ?: "همه دسته‌ها"}", fontWeight = FontWeight.Bold) }
        itemsIndexedCompat(keys.indices.reversed().toList()) { _, i ->
            val v = perMonth[i]
            val prev = if (i > 0) perMonth[i - 1] else null
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(pd(keys[i].first.toString()) + " " + Jalali.monthNames[keys[i].second - 1], Modifier.weight(1f))
                Text(money(v, toman), fontSize = 13.sp)
                if (prev != null && prev > 0) {
                    val ch = (v - prev) * 100.0 / prev
                    val up = ch >= 0
                    // for expenses rising is bad (red); for income rising is good (green)
                    val good = if (type == Cats.W) !up else up
                    Text(
                        "  " + (if (up) "▲" else "▼") + pd(String.format(Locale.US, "%.0f", kotlin.math.abs(ch))) + "٪",
                        fontSize = 12.sp, color = if (good) GREEN else RED
                    )
                }
            }
        }
        item { Text("جدول همه دسته‌ها", fontWeight = FontWeight.Bold) }
        item {
          Column {
            val shown = keys.takeLast(6)
            Row {
                Text("", Modifier.weight(1.6f))
                shown.forEach { k ->
                    Text(Jalali.monthNames[k.second - 1], Modifier.weight(1f), fontSize = 9.sp, textAlign = TextAlign.Center, maxLines = 1)
                }
            }
            catList.forEach { c ->
                val rows = all.filter { (it.category ?: "بدون دسته") == c }
                Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(c, Modifier.weight(1.6f), fontSize = 11.sp, maxLines = 2)
                    shown.forEach { k ->
                        val v = rows.filter { monthOf(it) == k }.sumOf { it.amount }
                        Text(if (v > 0) short(v, toman) else "–", Modifier.weight(1f), fontSize = 9.sp, textAlign = TextAlign.Center, maxLines = 1)
                    }
                }
            }
          }
        }
    }
}

@Composable
fun AccountBar(accts: List<Pair<String, String>>, sel: String?, onSel: (String?) -> Unit) {
    androidx.compose.foundation.lazy.LazyRow(
        Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item { FilterChip(sel == null, { onSel(null) }, { Text("همه حساب‌ها", fontSize = 13.sp) }) }
        items(accts.size) { i ->
            FilterChip(sel == accts[i].first, { onSel(accts[i].first) }, { Text(accts[i].second, fontSize = 13.sp) })
        }
    }
}

@Composable
fun AccountRow(key: String, name: String, onSave: (String) -> Unit) {
    var t by remember(key, name) { mutableStateOf(name) }
    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            t, { t = it }, singleLine = true, modifier = Modifier.weight(1f),
            label = { Text("شناسه: " + key.takeLast(8), fontSize = 11.sp) }
        )
        TextButton(onClick = { onSave(t) }) { Text("ذخیره") }
    }
}

// ---------------------------------------------------------------- settings
@Composable
fun SettingsScreen(db: Db, toman: Boolean, onRescan: () -> Unit, bump: () -> Unit, setToman: (Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(Cats.W) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("نمایش مبالغ به تومان", Modifier.weight(1f))
                Switch(toman, setToman)
            }
            Text("پیامک بانک‌ها معمولاً ریال است؛ با روشن بودن، مبلغ‌ها ÷۱۰ نمایش داده می‌شود.", fontSize = 12.sp, color = Color.Gray)
          }
        }
        item {
            Button(onClick = onRescan, modifier = Modifier.fillMaxWidth()) { Text("اسکن دوباره پیامک‌ها") }
        }
        item {
            Column {
                Text("حساب‌ها (نام دلخواه بدهید)", fontWeight = FontWeight.Bold)
                val accts = db.accounts()
                if (accts.isEmpty()) Text("هنوز پیامکی ثبت نشده است.", fontSize = 12.sp, color = Color.Gray)
                accts.forEach { (k, n) -> AccountRow(k, n) { db.renameAccount(k, it); bump() } }
            }
        }
        item {
          Column {
            Text("افزودن دسته جدید", fontWeight = FontWeight.Bold)
            TypeToggle(type) { type = it }
            OutlinedTextField(
                name, { name = it }, label = { Text("نام دسته") }, singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        db.addCat(name.trim(), type); name = ""; bump()
                    }
                },
                modifier = Modifier.padding(top = 6.dp)
            ) { Text("افزودن") }
            val mine = db.customCats(Cats.W) + db.customCats(Cats.D)
            if (mine.isNotEmpty()) Text("دسته‌های شما: " + mine.joinToString("، "), fontSize = 12.sp)
          }
        }
    }
}
