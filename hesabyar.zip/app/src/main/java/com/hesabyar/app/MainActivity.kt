package com.hesabyar.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val tick = mutableStateOf(0)
    private val pending = mutableStateOf(0L)
    private val db by lazy { Db.get(this) }

    private val launcher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { scanAsync(false) }

    private fun scanAsync(toast: Boolean) {
        val ok = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) ==
                PackageManager.PERMISSION_GRANTED
        if (!ok) {
            if (toast) Toast.makeText(this, "اجازه خواندن پیامک داده نشده است", Toast.LENGTH_LONG).show()
            return
        }
        Thread {
            val since = getSharedPreferences("settings", MODE_PRIVATE).getLong("install_ts", System.currentTimeMillis())
            val n = Importer.scan(this, db, since)
            runOnUiThread {
                tick.value = tick.value + 1
                if (toast) Toast.makeText(this, "$n تراکنش جدید پیدا شد", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        pending.value = intent?.getLongExtra("tx_id", 0L) ?: 0L
        if (!prefs.contains("install_ts")) prefs.edit().putLong("install_ts", System.currentTimeMillis()).apply()
        val perms = arrayListOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        launcher.launch(perms.toTypedArray())
        setContent {
            App(db, prefs, tick.value, pending.value, { pending.value = 0L }) { scanAsync(true) }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pending.value = intent.getLongExtra("tx_id", 0L)
    }

    override fun onResume() {
        super.onResume()
        scanAsync(false)
    }
}
