package com.hesabyar.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs == null || msgs.isEmpty()) return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val sender = msgs[0].originatingAddress ?: ""
        val p = SmsParser.parse(body) ?: return
        val id = Db.get(ctx).insert(System.currentTimeMillis(), p.type, p.amount, p.balance, body, sender, p.acct ?: sender)
        if (id < 0) return
        notify(ctx, p)
    }

    private fun notify(ctx: Context, p: Parsed) {
        try {
            val chId = "tx"
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.createNotificationChannel(
                    NotificationChannel(chId, "تراکنش جدید", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val kind = if (p.type == Cats.W) "برداشت" else "واریز"
            val n = NotificationCompat.Builder(ctx, chId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("$kind جدید: ${pd(String.format(java.util.Locale.US, "%,d", p.amount))} ریال")
                .setContentText("برای انتخاب دسته لمس کنید")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(ctx).notify((System.currentTimeMillis() % 100000).toInt(), n)
        } catch (e: Exception) {
        }
    }
}
