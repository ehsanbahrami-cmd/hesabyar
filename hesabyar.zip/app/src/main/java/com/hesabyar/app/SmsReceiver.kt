package com.hesabyar.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (msgs == null || msgs.isEmpty()) return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val sender = msgs[0].originatingAddress ?: ""
        val p = SmsParser.parse(body) ?: return
        val id = Db.get(ctx).insert(System.currentTimeMillis(), p.type, p.amount, p.balance, body, sender, p.acct ?: sender)
        if (id < 0) return

        val auto = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("auto_open", true)
        val open = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("tx_id", id)
        if (auto && Settings.canDrawOverlays(ctx)) {
            try {
                ctx.startActivity(open)
            } catch (e: Exception) {
            }
        }
        notify(ctx, p, id, open, auto)
    }

    private fun notify(ctx: Context, p: Parsed, id: Long, open: Intent, auto: Boolean) {
        try {
            val chId = "tx2"
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.createNotificationChannel(
                    NotificationChannel(chId, "تراکنش جدید", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val pi = PendingIntent.getActivity(
                ctx, id.toInt(), open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val kind = if (p.type == Cats.W) "برداشت" else "واریز"
            val b = NotificationCompat.Builder(ctx, chId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("$kind جدید: ${pd(String.format(java.util.Locale.US, "%,d", p.amount))} ریال")
                .setContentText("برای انتخاب دسته لمس کنید")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pi)
                .setAutoCancel(true)
            if (auto) b.setFullScreenIntent(pi, true)
            NotificationManagerCompat.from(ctx).notify(id.toInt(), b.build())
        } catch (e: Exception) {
        }
    }
}
