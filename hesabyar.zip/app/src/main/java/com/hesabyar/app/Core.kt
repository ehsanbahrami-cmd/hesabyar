package com.hesabyar.app

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import java.util.Calendar

// ---------------------------------------------------------------- Categories
object Cats {
    const val W = "W"
    const val D = "D"
    const val IGNORED = "#ignore"

    val withdraw = listOf(
        "مواد غذایی", "پوشاک", "هزینه پزشکی و دارو", "بنزین و روغن ماشین", "تعمیرات ماشین",
        "قسط وام", "چک", "لوازم منزل", "تعمیرات لوازم منزل", "تعمیرات ساختمان", "شارژ ساختمان",
        "قبض تلفن", "قبض موبایل و اینترنت", "قبض آب", "قبض گاز", "قبض برق",
        "رستوران و کافی‌شاپ", "هدیه به دیگران", "طلا و جواهرات", "پس‌انداز", "سرمایه‌گذاری",
        "خیرات", "آموزش و کتاب", "ورزش و تفریح", "مسافرت", "بیمه", "مالیات و عوارض",
        "تاکسی و حمل‌ونقل", "بهداشتی و آرایشی", "کارمزد بانکی", "انتقال به حساب خودم",
        "هزینه مدرسه", "کلاس موسیقی", "لوازم التحریر", "جریمه", "قهوه", "دخانیات", "دندانپزشکی", "متفرقه"
    )
    val deposit = listOf(
        "حقوق", "هدیه", "طلب", "فروش چیزی", "سود بانکی و سرمایه‌گذاری",
        "بازگشت وجه", "انتقال از حساب خودم", "متفرقه"
    )
}

// ---------------------------------------------------------------- Jalali calendar
object Jalali {
    val monthNames = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    fun toJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) +
                ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return Triple(jy, jm, jd)
    }

    fun toGregorian(jy0: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        val jy = jy0 + 1595
        var days = -355668 + (365 * jy) + ((jy / 33) * 8) + (((jy % 33) + 3) / 4) + jd +
                (if (jm < 7) (jm - 1) * 31 else ((jm - 7) * 30) + 186)
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days--
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)
        val sal = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 13 && gd > sal[gm]) {
            gd -= sal[gm]
            gm++
        }
        return Triple(gy, gm, gd)
    }

    fun fromMillis(ts: Long): Triple<Int, Int, Int> {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        return toJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    fun now(): Triple<Int, Int, Int> = fromMillis(System.currentTimeMillis())

    /** Start (00:00) of a Jalali day. Months/days beyond range are normalised for month only. */
    fun dayStart(jy: Int, jm: Int, jd: Int): Long {
        val idx = jy * 12 + (jm - 1)
        val y = Math.floorDiv(idx, 12)
        val m = Math.floorMod(idx, 12) + 1
        val (gy, gm, gd) = toGregorian(y, m, jd)
        val c = Calendar.getInstance()
        c.clear()
        c.set(gy, gm - 1, gd, 0, 0, 0)
        return c.timeInMillis
    }

    fun monthStart(jy: Int, jm: Int): Long = dayStart(jy, jm, 1)

    fun addMonths(jy: Int, jm: Int, delta: Int): Pair<Int, Int> {
        val idx = jy * 12 + (jm - 1) + delta
        return Pair(Math.floorDiv(idx, 12), Math.floorMod(idx, 12) + 1)
    }
}

// ---------------------------------------------------------------- SMS parser
data class Parsed(val type: String, val amount: Long, val balance: Long?, val acct: String? = null)

object SmsParser {
    fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            when (ch) {
                in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                '٬', '،' -> sb.append(',')
                'ي' -> sb.append('ی')
                'ك' -> sb.append('ک')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private val withdrawKeys = listOf(
        "برداشت", "خرید", "پرداخت", "کارت به کارت", "کارت‌به‌کارت", "انتقال از", "کسر",
        "پایا", "ساتنا", "قبض", "هزینه", "کارمزد", "withdraw", "purchase"
    )
    private val depositKeys = listOf(
        "واریز", "دریافت", "سپرده", "افزایش", "بهره", "سود", "deposit", "credit"
    )
    private val skipWords = listOf("رمز", "کد فعال", "کد تایید", "کد تأیید", "otp", "password")
    private val amountRe = Regex("(?<![\\d,/.*])(\\d{1,3}(?:,\\d{3})+|\\d{4,})(?![\\d,/:.*])")
    private val noAmountBefore = listOf("حساب", "کارت", "شماره", "شبا", "پیگیری", "مرجع")

    fun parse(raw: String): Parsed? {
        val text = norm(raw)
        val low = text.lowercase()
        if (skipWords.any { low.contains(it) }) return null

        val balIdx = Regex("مانده|موجودی|balance").find(low)?.range?.first ?: -1
        val main = if (balIdx > 0) text.substring(0, balIdx) else text
        val mainLow = main.lowercase()

        var balance: Long? = null
        if (balIdx >= 0) {
            val tail = text.substring(balIdx)
            balance = amountRe.find(tail)?.groupValues?.get(1)?.replace(",", "")?.toLongOrNull()
        }

        var wIdx = Int.MAX_VALUE
        for (k in withdrawKeys) {
            val i = mainLow.indexOf(k)
            if (i >= 0 && i < wIdx) wIdx = i
        }
        var dIdx = Int.MAX_VALUE
        for (k in depositKeys) {
            val i = mainLow.indexOf(k)
            if (i >= 0 && i < dIdx) dIdx = i
        }
        var type: String? = when {
            wIdx == Int.MAX_VALUE && dIdx == Int.MAX_VALUE -> null
            wIdx < dIdx -> Cats.W
            else -> Cats.D
        }

        var amount: Long? = null
        var amountSign = 0
        val cands = amountRe.findAll(main).filter { it.groupValues[1].replace(",", "").length <= 12 }.toList()
        val ordered = cands.filter { it.groupValues[1].contains(',') } + cands.filter { !it.groupValues[1].contains(',') }
        for (m in ordered) {
            val start = m.range.first
            val before = main.substring(maxOf(0, start - 10), start)
            if (noAmountBefore.any { before.contains(it) }) continue
            amount = m.groupValues[1].replace(",", "").toLongOrNull()
            val prev = if (start > 0) main[start - 1] else ' '
            val nextIdx = m.range.last + 1
            val next = if (nextIdx < main.length) main[nextIdx] else ' '
            amountSign = when {
                prev == '+' || next == '+' -> 1
                prev == '-' || next == '-' -> -1
                else -> 0
            }
            break
        }
        if (amount == null || amount <= 0) return null
        if (type == null) {
            type = when (amountSign) {
                1 -> Cats.D
                -1 -> Cats.W
                else -> return null
            }
        }
        val acct = Regex("حساب\\s*:?\\s*(\\d{3,})").find(main)?.groupValues?.get(1)
            ?: Regex("(?<![\\d,])\\d{13,}(?![\\d,])").find(main)?.value
        return Parsed(type, amount, balance, acct)
    }
}

// ---------------------------------------------------------------- Database
data class Tx(
    val id: Long, val ts: Long, val type: String, val amount: Long, val balance: Long?,
    val category: String?, val body: String, val sender: String, val acct: String = "", val note: String = ""
)

class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "hesab.db", null, 3) {
    companion object {
        @Volatile
        private var inst: Db? = null
        fun get(ctx: Context): Db = inst ?: synchronized(this) {
            inst ?: Db(ctx.applicationContext).also { inst = it }
        }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, type TEXT, " +
                    "amount INTEGER, balance INTEGER, category TEXT, body TEXT, sender TEXT, acct TEXT DEFAULT '', note TEXT DEFAULT '')"
        )
        db.execSQL("CREATE TABLE cat(name TEXT, type TEXT, PRIMARY KEY(name, type))")
        db.execSQL("CREATE TABLE acc(k TEXT PRIMARY KEY, name TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) {
            db.execSQL("ALTER TABLE tx ADD COLUMN acct TEXT DEFAULT ''")
            db.execSQL("CREATE TABLE IF NOT EXISTS acc(k TEXT PRIMARY KEY, name TEXT)")
        }
        if (o < 3) {
            db.execSQL("ALTER TABLE tx ADD COLUMN note TEXT DEFAULT ''")
        }
    }

    /** returns new id, or -1 if duplicate */
    @Synchronized
    fun insert(ts: Long, type: String, amount: Long, balance: Long?, body: String, sender: String, acct: String): Long {
        val dup = readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM tx WHERE sender=? AND body=? AND ts BETWEEN ? AND ?",
            arrayOf(sender, body, (ts - 600000).toString(), (ts + 600000).toString())
        )
        dup.use { if (it.moveToFirst() && it.getInt(0) > 0) return -1 }
        val cv = ContentValues()
        cv.put("ts", ts)
        cv.put("type", type)
        cv.put("amount", amount)
        if (balance != null) cv.put("balance", balance)
        cv.put("body", body)
        cv.put("sender", sender)
        cv.put("acct", acct)
        return writableDatabase.insert("tx", null, cv)
    }

    private fun read(c: Cursor): List<Tx> {
        val out = ArrayList<Tx>()
        while (c.moveToNext()) {
            out.add(
                Tx(
                    c.getLong(c.getColumnIndexOrThrow("id")),
                    c.getLong(c.getColumnIndexOrThrow("ts")),
                    c.getString(c.getColumnIndexOrThrow("type")),
                    c.getLong(c.getColumnIndexOrThrow("amount")),
                    if (c.isNull(c.getColumnIndexOrThrow("balance"))) null
                    else c.getLong(c.getColumnIndexOrThrow("balance")),
                    c.getString(c.getColumnIndexOrThrow("category")),
                    c.getString(c.getColumnIndexOrThrow("body")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("sender")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("acct")) ?: "",
                    c.getString(c.getColumnIndexOrThrow("note")) ?: ""
                )
            )
        }
        return out
    }

    fun query(from: Long, to: Long, type: String?, onlyUncategorized: Boolean, acct: String? = null): List<Tx> {
        val sb = StringBuilder("ts>=? AND ts<? AND (category IS NULL OR category!='${Cats.IGNORED}')")
        val args = arrayListOf(from.toString(), to.toString())
        if (type != null) {
            sb.append(" AND type=?")
            args.add(type)
        }
        if (onlyUncategorized) sb.append(" AND category IS NULL")
        if (acct != null) {
            sb.append(" AND acct=?")
            args.add(acct)
        }
        val c = readableDatabase.query("tx", null, sb.toString(), args.toTypedArray(), null, null, "ts DESC")
        return c.use { read(it) }
    }

    fun update(id: Long, category: String?, type: String, amount: Long, note: String) {
        val cv = ContentValues()
        if (category == null) cv.putNull("category") else cv.put("category", category)
        cv.put("type", type)
        cv.put("amount", amount)
        cv.put("note", note)
        writableDatabase.update("tx", cv, "id=?", arrayOf(id.toString()))
    }

    fun getById(id: Long): Tx? {
        val c = readableDatabase.query("tx", null, "id=?", arrayOf(id.toString()), null, null, null)
        return c.use { read(it).firstOrNull() }
    }

    fun accounts(): List<Pair<String, String>> {
        val keys = ArrayList<String>()
        val c = readableDatabase.rawQuery("SELECT DISTINCT acct FROM tx WHERE acct IS NOT NULL AND acct!='' AND (category IS NULL OR category!='${Cats.IGNORED}')", null)
        c.use { while (it.moveToNext()) keys.add(it.getString(0)) }
        val names = HashMap<String, String>()
        val c2 = readableDatabase.rawQuery("SELECT k, name FROM acc", null)
        c2.use { while (it.moveToNext()) names[it.getString(0)] = it.getString(1) }
        return keys.map { k -> Pair(k, names[k] ?: defaultName(k)) }
    }

    fun defaultName(k: String): String =
        if (k.all { it.isDigit() }) "حساب " + k.takeLast(5) else k

    /** Hides the account and all its transactions (kept as ignored so rescan won't bring them back). */
    fun deleteAccount(k: String) {
        writableDatabase.execSQL("UPDATE tx SET category=? WHERE acct=?", arrayOf(Cats.IGNORED, k))
        writableDatabase.delete("acc", "k=?", arrayOf(k))
    }

    fun renameAccount(k: String, name: String) {
        val cv = ContentValues()
        cv.put("k", k)
        cv.put("name", name.trim().ifEmpty { defaultName(k) })
        writableDatabase.insertWithOnConflict("acc", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun customCats(type: String): List<String> {
        val c = readableDatabase.query("cat", arrayOf("name"), "type=?", arrayOf(type), null, null, "rowid")
        val out = ArrayList<String>()
        c.use { while (it.moveToNext()) out.add(it.getString(0)) }
        return out
    }

    fun addCat(name: String, type: String) {
        val cv = ContentValues()
        cv.put("name", name)
        cv.put("type", type)
        writableDatabase.insertWithOnConflict("cat", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun allCats(type: String): List<String> {
        val base = if (type == Cats.W) Cats.withdraw else Cats.deposit
        return base + customCats(type)
    }
}

// ---------------------------------------------------------------- Import
object Importer {
    fun addIfBank(db: Db, sender: String, body: String, ts: Long): Long {
        val p = SmsParser.parse(body) ?: return -1
        return db.insert(ts, p.type, p.amount, p.balance, body, sender, p.acct ?: sender)
    }

    /** Scan inbox for messages received after [since] (install time). Returns number of new transactions. */
    fun scan(ctx: Context, db: Db, since: Long): Int {
        var n = 0
        val c = ctx.contentResolver.query(
            Uri.parse("content://sms/inbox"), arrayOf("address", "body", "date"),
            "date>?", arrayOf(since.toString()), "date DESC"
        ) ?: return 0
        c.use {
            while (it.moveToNext()) {
                val a = it.getString(0) ?: ""
                val b = it.getString(1) ?: ""
                val d = it.getLong(2)
                if (addIfBank(db, a, b, d) > 0) n++
            }
        }
        return n
    }
}
